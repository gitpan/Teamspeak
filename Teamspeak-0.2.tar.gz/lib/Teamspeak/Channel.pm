# $Id: Channel.pm 21 2005-04-12 13:30:26Z maletin $
# $URL: svn+ssh://svn.berlios.de/svnroot/repos/cpan-teamspeak/cpan/trunk/lib/Teamspeak/Channel.pm $

package Teamspeak::Channel;

use strict;
use vars qw( $VERSION );
$VERSION = '0.2';

sub new {
}

1;
