# $Id: Player.pm 21 2005-04-12 13:30:26Z maletin $
# $URL: svn+ssh://svn.berlios.de/svnroot/repos/cpan-teamspeak/cpan/trunk/lib/Teamspeak/Player.pm $


package Teamspeak::Player;

use strict;
use vars qw( $VERSION );
$VERSION = '0.2';

sub new {
  my( $self, %args ) = @_;
}   # new

1;
